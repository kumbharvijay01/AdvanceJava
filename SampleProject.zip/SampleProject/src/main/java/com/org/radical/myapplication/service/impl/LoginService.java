/**
 * 
 */
package com.org.radical.myapplication.service.impl;

import com.org.radical.myapplication.model.Users;

/**
 * 
 */
public interface LoginService {
	public Users getUser(String username, String password);

}
