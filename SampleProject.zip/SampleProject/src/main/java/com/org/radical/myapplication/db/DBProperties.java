/**
 * 
 */
package com.org.radical.myapplication.db;

/**
 * @author vijaykumbhar
 *
 */
public class DBProperties {

	public final String url = "jdbc:mysql://localhost:3306/development";
	public final String userName = "root";
	public final String password = "Welcome@129#2022";

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

}
