/**
 * 
 */
package com.org.radical.myapplication.util;

/**
 * 
 */
public class Utility {

}
